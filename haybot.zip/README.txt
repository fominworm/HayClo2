HayBot 2.0

С ТЕЛЕФОНА:
1. Создай репозиторий на GitHub.
2. Add file -> Upload files -> загрузи haybot.zip (НЕ распаковывай). Commit.
3. Add file -> Create new file -> имя: .github/workflows/build.yml
   Вставь содержимое файла build.yml. Commit.
4. Вкладка Actions -> Build HayBot APK -> когда закончится, внизу Artifacts -> HayBot-APK.
   (Скачается zip, внутри app-debug.apk.)

Если Actions красный — открой упавший шаг, скопируй текст ошибки.
