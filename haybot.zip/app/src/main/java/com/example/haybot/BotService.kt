package com.example.haybot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

private enum class H { DONE, NOT_RIPE, FAIL }

class BotService : AccessibilityService() {
    companion object {
        @Volatile var instance: BotService? = null
        const val GAME_PKG = "com.supercell.hayday"
        private const val AD_COOLDOWN_MS = 300_000L
    }

    private lateinit var wm: WindowManager
    private lateinit var cfg: Cfg
    private lateinit var markView: MarkView
    private lateinit var markParams: WindowManager.LayoutParams
    private lateinit var panel: LinearLayout
    private lateinit var panelParams: WindowManager.LayoutParams
    private lateinit var body: LinearLayout
    private lateinit var tvStatus: TextView
    private lateinit var tvHint: TextView
    private lateinit var btnPrimary: Button
    private lateinit var btnSecondary: Button
    private lateinit var btnBack: Button
    private val mainHandler = Handler(Looper.getMainLooper())

    private val fBase = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
    private val fPass = fBase or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE

    @Volatile private var running = false
    private var worker: Thread? = null
    private var stepIdx = 0
    private var lastAdMs = 0L
    private var shopMisses = 0
    private var notRipeStreak = 0

    // ---------------- lifecycle ----------------

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        cfg = Cfg(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        initOverlay()
        cfg.onExternalChange = { mainHandler.post { markView.invalidate(); if (!running) showIdleUi() } }
        showIdleUi()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopBot() }
    override fun onDestroy() {
        stopBot()
        runCatching { wm.removeView(markView) }
        runCatching { wm.removeView(panel) }
        instance = null
        super.onDestroy()
    }

    // ---------------- overlay ----------------

    private fun overlayType() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
    else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun initOverlay() {
        val dm = resources.displayMetrics
        markView = MarkView(this, cfg)
        markParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(), fPass, PixelFormat.TRANSLUCENT
        )
        wm.addView(markView, markParams)

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xDD1E1E24.toInt())
            setPadding(24, 16, 24, 16)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val dragTv = TextView(this).apply { text = "≡ HayBot "; setTextColor(Color.parseColor("#FFCA28")); textSize = 14f }
        tvStatus = TextView(this).apply {
            text = "Готов"; setTextColor(Color.WHITE); textSize = 12f
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val btnEye = Button(this).apply {
            text = "👁"; textSize = 11f
            setOnClickListener { markView.showAll = !markView.showAll; markView.invalidate() }
        }
        val btnMin = Button(this).apply {
            text = "–"; textSize = 11f
            setOnClickListener {
                val show = body.visibility != View.VISIBLE
                body.visibility = if (show) View.VISIBLE else View.GONE
                text = if (show) "–" else "+"
            }
        }
        header.addView(dragTv); header.addView(tvStatus); header.addView(btnEye); header.addView(btnMin)

        tvHint = TextView(this).apply { setTextColor(0xFFCCCCCC.toInt()); textSize = 11f; setPadding(0, 6, 0, 8) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnBack = Button(this).apply {
            text = "↩"; visibility = View.GONE
            setOnClickListener { if (stepIdx > 0) { stepIdx--; renderStep() } else showIdleUi() }
        }
        btnPrimary = Button(this).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        btnSecondary = Button(this).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        row.addView(btnBack); row.addView(btnPrimary); row.addView(btnSecondary)

        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(tvHint); body.addView(row)
        panel.addView(header); panel.addView(body)

        val w = min((dm.widthPixels * 0.45f).toInt(), 720)
        panelParams = WindowManager.LayoutParams(w, -2, overlayType(), fBase, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = 30; y = 100
        }
        var ix = 0; var iy = 0; var tx = 0f; var ty = 0f
        header.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { ix = panelParams.x; iy = panelParams.y; tx = e.rawX; ty = e.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    panelParams.x = ix + (e.rawX - tx).toInt()
                    panelParams.y = iy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(panel, panelParams); true
                }
                else -> false
            }
        }
        wm.addView(panel, panelParams)
    }

    private fun armMark(armed: Boolean, rect: Boolean = false, swipe: Boolean = false) {
        mainHandler.post {
            markView.armed = armed; markView.editMode = rect; markView.swipeMode = swipe
            markParams.flags = if (armed) fBase else fPass
            runCatching { wm.updateViewLayout(markView, markParams) }
            markView.invalidate()
        }
    }

    private fun status(s: String) { mainHandler.post { if (running) tvStatus.text = s } }

    // ---------------- idle / start ----------------

    private fun showIdleUi() {
        mainHandler.post {
            armMark(false)
            markView.onTap = null; markView.onSwipe = null
            val miss = cfg.missing()
            tvStatus.text = (if (running) "🟢 В работе" else "⚪ Готов") + " | Силос: ${cfg.barnUsed}/${cfg.barnCap}"
            tvHint.text = if (miss != null) "Нужна калибровка: ${miss.icon} ${miss.label}" else "Все точки настроены. Нажми Старт."
            btnBack.visibility = View.GONE
            btnPrimary.text = if (running) "⏹ Стоп" else "▶ Старт"
            btnPrimary.setOnClickListener { if (running) stopBot() else askSiloAndStart() }
            btnSecondary.visibility = if (running) View.GONE else View.VISIBLE
            btnSecondary.text = "⚙ Мастер"
            btnSecondary.setOnClickListener { if (!running) { stepIdx = 0; renderStep() } }
        }
    }

    private fun askSiloAndStart() {
        if (cfg.missing() != null) { stepIdx = 0; renderStep(); return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 10) }
        fun field(lbl: String, v: Int): EditText {
            box.addView(TextView(this).apply { text = lbl })
            val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(v.toString()) }
            box.addView(et)
            return et
        }
        val eCells = field("Количество грядок:", cfg.cells)
        val eUsed = field("Сейчас занято в силосе:", cfg.barnUsed)
        val eCap = field("Лимит силоса:", cfg.barnCap)
        val dlg = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Контроль силоса")
            .setView(box)
            .setPositiveButton("Старт") { _, _ ->
                cfg.cells = eCells.text.toString().toIntOrNull() ?: cfg.cells
                cfg.barnUsed = eUsed.text.toString().toIntOrNull() ?: cfg.barnUsed
                cfg.barnCap = eCap.text.toString().toIntOrNull() ?: cfg.barnCap
                startLoop()
            }
            .setNegativeButton("Отмена", null).create()
        dlg.window?.setType(overlayType())
        dlg.show()
    }

    // ---------------- wizard ----------------

    private fun nextStep() { if (stepIdx + 1 < FLOW.size) { stepIdx++; renderStep() } else showIdleUi() }
    private fun jumpToClose() { stepIdx = FLOW.indexOfFirst { it.role == T.CLOSE }.coerceAtLeast(stepIdx + 1); renderStep() }

    private fun renderStep() {
        val s = FLOW[stepIdx]
        tvStatus.text = "Шаг ${stepIdx + 1}/${FLOW.size}: ${s.text}"
        tvHint.text = s.hint
        btnBack.visibility = View.VISIBLE
        markView.onTap = null; markView.onSwipe = null; markView.editPts = null
        when (s.kind) {
            Kind.INFO, Kind.WAIT -> {
                armMark(false)
                btnPrimary.text = s.btn ?: "Дальше ▶"; btnPrimary.setOnClickListener { nextStep() }
                btnSecondary.visibility = View.GONE
            }
            Kind.ASK -> {
                armMark(false)
                btnPrimary.text = s.btn ?: "Да ▶"; btnPrimary.setOnClickListener { nextStep() }
                btnSecondary.visibility = View.VISIBLE
                btnSecondary.text = s.skip ?: "Пропустить"
                btnSecondary.setOnClickListener { showIdleUi() }
            }
            Kind.RECT -> {
                val area = cfg.list(T.AREA).toMutableList()
                if (area.size < 4) {
                    val dm = resources.displayMetrics
                    val cx = dm.widthPixels / 2f; val cy = dm.heightPixels / 2f
                    area.clear()
                    area.add(P(cx - 220f, cy)); area.add(P(cx, cy - 130f)); area.add(P(cx + 220f, cy)); area.add(P(cx, cy + 130f))
                }
                markView.editPts = area
                armMark(true, rect = true)
                btnPrimary.text = s.btn ?: "Готово ✓"
                btnPrimary.setOnClickListener {
                    cfg.clear(T.AREA); area.forEach { cfg.add(T.AREA, it) }
                    markView.editPts = null; nextStep()
                }
                btnSecondary.visibility = View.GONE
            }
            Kind.TAP -> {
                armMark(true)
                btnPrimary.text = "Жду тапа..."; btnPrimary.setOnClickListener(null)
                if (s.skip != null) {
                    btnSecondary.visibility = View.VISIBLE; btnSecondary.text = s.skip
                    btnSecondary.setOnClickListener { nextStep() }
                } else btnSecondary.visibility = View.GONE
                markView.onTap = { x, y ->
                    val pt = P(x, y)
                    val role = s.role
                    if (role != null) {
                        if (role.multi && s.fresh) cfg.clear(role)   // фикс: слоты больше не дублируются
                        cfg.add(role, pt)
                    }
                    armMark(false)
                    thread {
                        if (s.sample && role != null) {
                            Thread.sleep(150)
                            val bmp = takeScreen()
                            if (bmp != null) {
                                cfg.setRef(role, Vision.sampleColor(bmp, pt))
                                if (role == T.ITEM) cfg.setWheatPatch(Vision.extractPatch(bmp, pt))
                                bmp.recycle()
                            }
                        }
                        if (s.replay) { Thread.sleep(120); tapSync(pt); Thread.sleep(s.settle) }
                        mainHandler.post { nextStep() }
                    }
                }
            }
            Kind.MULTI -> {
                val role = s.role
                if (s.fresh && role != null) cfg.clear(role)
                armMark(true)
                btnPrimary.text = s.btn ?: "Готово ✓"; btnPrimary.setOnClickListener { nextStep() }
                if (s.skip != null) {
                    btnSecondary.visibility = View.VISIBLE; btnSecondary.text = s.skip
                    btnSecondary.setOnClickListener { nextStep() }
                } else btnSecondary.visibility = View.GONE
                markView.onTap = { x, y ->
                    val pt = P(x, y)
                    if (role != null && (s.max == 0 || cfg.list(role).size < s.max)) cfg.add(role, pt)
                    markView.invalidate()
                    if (s.replay) {
                        armMark(false)
                        thread { Thread.sleep(100); tapSync(pt); Thread.sleep(450); mainHandler.post { armMark(true) } }
                    }
                }
            }
            Kind.SWIPE -> {
                armMark(true, swipe = true)
                btnPrimary.text = "Свайпни..."; btnPrimary.setOnClickListener(null)
                if (s.skip != null) {
                    btnSecondary.visibility = View.VISIBLE; btnSecondary.text = s.skip
                    // фикс: раньше «Один экран» завершал мастер и пропускал калибровку крестика
                    btnSecondary.setOnClickListener { cfg.shopPages = 1; jumpToClose() }
                } else btnSecondary.visibility = View.GONE
                markView.onSwipe = { p1, p2, dur ->
                    val role = s.role
                    if (role != null) { cfg.clear(role); cfg.add(role, p1); cfg.add(role, p2) }
                    cfg.swipeMs = dur.toInt().coerceIn(400, 2000)
                    cfg.shopPages = max(2, cfg.shopPages)
                    armMark(false)
                    thread { Thread.sleep(150); swipeSync(p1, p2, cfg.swipeMs.toLong()); Thread.sleep(650); mainHandler.post { nextStep() } }
                }
            }
            Kind.DO -> {
                armMark(false)
                btnPrimary.text = s.btn ?: "Выполнить"
                btnPrimary.setOnClickListener {
                    thread {
                        when (s.act) {
                            "plant" -> doPlant()
                            "harvest" -> doHarvest()
                            "swipe2" -> {
                                val sw = cfg.list(T.SWIPE)
                                if (sw.size >= 2) { cfg.shopPages = 3; swipeSync(sw[0], sw[1], cfg.swipeMs.toLong()); Thread.sleep(650) }
                            }
                        }
                        mainHandler.post { nextStep() }
                    }
                }
                if (s.skip != null) {
                    btnSecondary.visibility = View.VISIBLE; btnSecondary.text = s.skip
                    btnSecondary.setOnClickListener { jumpToClose() }
                } else btnSecondary.visibility = View.GONE
            }
        }
    }

    // ---------------- main loop ----------------

    private fun startLoop() {
        if (running) return
        running = true; notRipeStreak = 0
        showIdleUi()
        worker = thread {
            var err: String? = null
            try { mainLoop() } catch (e: Exception) { err = e.message ?: e.javaClass.simpleName }
            running = false
            mainHandler.post { showIdleUi(); if (err != null) tvHint.text = "Ошибка: $err" }
        }
    }

    fun stopBot() { running = false; worker?.interrupt(); worker = null; showIdleUi() }

    private fun nearFull(gain: Int) = cfg.barnCap > 0 && cfg.barnUsed + gain > cfg.barnCap - cfg.margin

    private fun mainLoop() {
        var cycle = 0
        while (running) {
            cycle++
            val gain = cfg.cells * cfg.perCell
            val hasShop = cfg.shopReady()

            if (hasShop && nearFull(gain)) {
                status("Силос почти полон (${cfg.barnUsed}/${cfg.barnCap}) → продажа")
                sellInShop(gain)
            }
            if (!running) break

            recoverPopups()
            status("Круг $cycle: сбор урожая...")
            val h = harvestWithRetry(if (cycle == 1) 0 else cfg.ripeRetries)
            if (!running) break
            if (h == H.NOT_RIPE && cycle > 1) {
                notRipeStreak++
                if (notRipeStreak < 3) continue        // не сажаем поверх несозревшего, ждём ещё
            }
            notRipeStreak = 0
            if (h == H.DONE && cfg.cells > 0) {
                val cap = if (cfg.barnCap > 0) cfg.barnCap else Int.MAX_VALUE
                cfg.barnUsed = min(cap, cfg.barnUsed + gain)
            }
            sleepMs(Geo.jitterDelay(550))
            if (!running) break

            status("Круг $cycle: посев поля...")
            if (doPlant() && cfg.cells > 0) cfg.barnUsed = max(0, cfg.barnUsed - cfg.cells)
            val plantedAt = System.currentTimeMillis()
            if (!running) break

            val full = nearFull(gain)
            if (hasShop && (full || cycle % cfg.sellEvery == 0)) {
                status("Продажа в лавке во время роста...")
                sellInShop(if (full) gain else cfg.perSlot * 2)
            }
            if (!running) break

            val left = (cfg.grow - (System.currentTimeMillis() - plantedAt) / 1000L).toInt().coerceAtLeast(0)
            waitSec(left, "⏳ Круг $cycle, рост")
        }
    }

    private fun waitSec(sec: Int, label: String) {
        val end = System.currentTimeMillis() + sec * 1000L
        while (running) {
            val rem = (end - System.currentTimeMillis()) / 1000L
            if (rem <= 0L) break
            status("$label: ${rem}с | Силос: ${cfg.barnUsed}/${cfg.barnCap}")
            sleepMs(1000L)
        }
    }

    private fun harvestWithRetry(retries: Int): H {
        var tries = 0
        while (running) {
            val r = doHarvest()
            if (r != H.NOT_RIPE) return r
            if (tries++ >= retries) return H.NOT_RIPE
            waitSec(cfg.ripeWaitSec, "Не созрело, повтор ${tries}/$retries")
        }
        return H.FAIL
    }

    // ---------------- game actions ----------------

    private fun doPlant(): Boolean {
        val fp = cfg.first(T.FIELD) ?: return false
        val wp = cfg.first(T.WHEAT) ?: return false
        val area = cfg.list(T.AREA)
        if (area.size < 4) return false
        tapSync(Geo.jitterTap(fp))
        sleepMs(Geo.jitterDelay(750))
        val dm = resources.displayMetrics
        val snake = Geo.snake(area, cfg.rowGap.toFloat(), fp, dm.widthPixels, dm.heightPixels, cfg.edgePct)
        val ok = holdSweepReturnSync(wp, fp, snake, Geo.jitterDelay(cfg.holdMs.toLong()), cfg.returnHand)
        lockGround()
        return ok
    }

    private fun doHarvest(): H {
        val hp = cfg.first(T.HFIELD) ?: cfg.first(T.FIELD) ?: return H.FAIL
        val sp = cfg.first(T.SICKLE) ?: return H.FAIL
        val area = cfg.list(T.AREA)
        if (area.size < 4) return H.FAIL
        val ref = cfg.getRef(T.HFIELD)
        if (cfg.useRec && ref != null) {
            val bmp = takeScreen()
            if (bmp != null) {
                val ok = Vision.matchesColor(bmp, hp, ref, 58.0)
                bmp.recycle()
                if (!ok) return H.NOT_RIPE
            }
        }
        tapSync(Geo.jitterTap(hp))
        sleepMs(Geo.jitterDelay(750))
        val dm = resources.displayMetrics
        val snake = Geo.snake(area, cfg.rowGap.toFloat(), hp, dm.widthPixels, dm.heightPixels, cfg.edgePct)
        val ok = holdSweepReturnSync(sp, hp, snake, Geo.jitterDelay(cfg.holdMs.toLong()), cfg.returnHand)
        lockGround()
        return if (ok) H.DONE else H.FAIL
    }

    private fun lockGround() {
        val gp = cfg.first(T.GROUND) ?: return
        sleepMs(40L)
        holdPointSync(Geo.jitterTap(gp), Geo.jitterDelay(cfg.groundMs.toLong()))
        sleepMs(100L)
    }

    /** Если на экране виден красный крестик окна (по цвету из калибровки) — закрываем. */
    private fun recoverPopups() {
        if (!cfg.useRec) return
        val cp = cfg.first(T.CLOSE) ?: return
        val ref = cfg.getRef(T.CLOSE) ?: return
        for (i in 0 until 2) {
            val bmp = takeScreen() ?: return
            val open = Vision.matchesColor(bmp, cp, ref, 40.0)
            bmp.recycle()
            if (!open) return
            status("Закрываю лишнее окно...")
            tapSync(Geo.jitterTap(cp))
            sleepMs(Geo.jitterDelay(700))
        }
    }

    private fun slotsFor(pg: Int): List<P> = when (pg) {
        0 -> cfg.list(T.SLOT)
        1 -> cfg.list(T.SLOT2).ifEmpty { cfg.list(T.SLOT) }
        else -> cfg.list(T.SLOT3).ifEmpty { cfg.list(T.SLOT2).ifEmpty { cfg.list(T.SLOT) } }
    }

    private fun putVisible(putPt: P, refPut: Int?): Boolean {
        if (!cfg.useRec || refPut == null) return true
        val bmp = takeScreen() ?: return true
        val ok = Vision.matchesColor(bmp, putPt, refPut, 52.0)
        bmp.recycle()
        return ok
    }

    private fun sellInShop(targetFree: Int) {
        val shopPt = cfg.first(T.SHOP) ?: return
        val putPt = cfg.first(T.PUT) ?: return
        val closePt = cfg.first(T.CLOSE) ?: return
        tapSync(Geo.jitterTap(shopPt))
        sleepMs(Geo.jitterDelay(950))

        val wpat = cfg.getWheatPatch()
        val cands = cfg.list(T.ITEMS).ifEmpty { cfg.list(T.ITEM) }
        val extras = cfg.list(T.EXTRA)
        val adPt = cfg.first(T.AD)
        val refPut = cfg.getRef(T.PUT)
        val pages = cfg.shopPages
        var sold = 0
        var notFound = false

        loop@ for (pg in 0 until pages) {
            if (!running) break
            val slots = slotsFor(pg)
            for ((idx, sl) in slots.withIndex()) {
                if (!running || cfg.barnUsed < cfg.perSlot) break@loop
                tapSync(Geo.jitterTap(sl))
                sleepMs(Geo.jitterDelay(420))
                var open = putVisible(putPt, refPut)
                if (!open) {
                    tapSync(Geo.jitterTap(sl))
                    sleepMs(Geo.jitterDelay(480))
                    open = putVisible(putPt, refPut)
                }
                if (!open) continue

                var crop: P? = cfg.first(T.ITEM)
                if (cands.isNotEmpty() && wpat != null) {
                    val bmp = takeScreen()
                    if (bmp != null) { crop = Vision.findCrop(bmp, cands, wpat); bmp.recycle() }
                }
                if (crop == null) {
                    notFound = true
                    tapSync(Geo.jitterTap(closePt)); sleepMs(400L)
                    break@loop
                }
                tapSync(Geo.jitterTap(crop))
                sleepMs(Geo.jitterDelay(380))
                for (ex in extras) { tapSync(Geo.jitterTap(ex)); sleepMs(Geo.jitterDelay(250)) }

                val nextSold = sold + cfg.perSlot
                val nextRem = cfg.barnUsed - cfg.perSlot
                val isLast = (pg == pages - 1 && idx == slots.size - 1) || nextSold >= targetFree || nextRem < cfg.perSlot
                val now = System.currentTimeMillis()
                if (isLast && adPt != null && now - lastAdMs >= AD_COOLDOWN_MS) {
                    tapSync(Geo.jitterTap(adPt))
                    sleepMs(Geo.jitterDelay(320))
                    lastAdMs = System.currentTimeMillis()
                }
                tapSync(Geo.jitterTap(putPt))
                sleepMs(Geo.jitterDelay(520))
                cfg.barnUsed = max(0, cfg.barnUsed - cfg.perSlot)
                sold += cfg.perSlot
                if (nextSold >= targetFree) break@loop
            }
            if (pg + 1 < pages) {
                val sw = cfg.list(T.SWIPE)
                if (sw.size >= 2) { swipeSync(sw[0], sw[1], cfg.swipeMs.toLong()); sleepMs(Geo.jitterDelay(550)) } else break
            }
        }

        // самокоррекция счётчика силоса: два раза подряд пшеницы в списке нет → считаем, что её нет
        if (notFound) {
            shopMisses++
            if (shopMisses >= 2) { cfg.barnUsed = 0; shopMisses = 0 }
        } else if (sold > 0) shopMisses = 0

        tapSync(Geo.jitterTap(closePt))
        sleepMs(Geo.jitterDelay(550))
        lockGround()
    }

    // ---------------- foreground guard ----------------

    private fun gameForeground(): Boolean {
        val pkg: String? = runCatching { rootInActiveWindow?.packageName?.toString() }.getOrNull()
        if (pkg == null) return true
        return pkg == GAME_PKG || pkg == packageName
    }

    private fun waitForGame() {
        var announced = false
        while (running && !gameForeground()) {
            if (!announced) { status("⏸ Hay Day не на экране — жду"); announced = true }
            sleepMs(1500L)
        }
        if (announced && running) sleepMs(2500L)
    }

    // ---------------- gestures ----------------

    private fun tapSync(p: P): Boolean {
        val path = Path().apply { moveTo(p.x, p.y) }
        return dispatchSync(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0L, 55L)).build())
    }

    private fun holdPointSync(p: P, ms: Long): Boolean {
        val path = Path().apply { moveTo(p.x, p.y); lineTo(p.x + 0.5f, p.y + 0.5f) }
        return dispatchSync(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0L, ms.coerceIn(100L, 10000L))).build())
    }

    private fun swipeSync(p1: P, p2: P, ms: Long): Boolean {
        val path = Path().apply { moveTo(p1.x, p1.y); lineTo(p2.x, p2.y) }
        return dispatchSync(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0L, ms.coerceIn(150L, 5000L))).build())
    }

    private fun holdSweepReturnSync(icon: P, start: P, snake: List<P>, holdMs: Long, ret: Boolean): Boolean {
        if (snake.isEmpty()) return false
        val pts = ArrayList<P>()
        pts.add(icon); pts.add(start); pts.addAll(snake); if (ret) pts.add(start)
        var dist = 0f
        for (i in 1 until pts.size) dist += hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y)
        val sweepMs = (dist / 1.4f).toLong().coerceIn(900L, 11000L)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val p1 = Path().apply { moveTo(icon.x, icon.y); lineTo(icon.x + 1f, icon.y + 1f) }
            val s1 = GestureDescription.StrokeDescription(p1, 0L, holdMs.coerceIn(150L, 3000L), true)
            if (!dispatchSync(GestureDescription.Builder().addStroke(s1).build())) return false
            val p2 = Path().apply {
                moveTo(icon.x + 1f, icon.y + 1f); lineTo(start.x, start.y)
                for (pt in snake) lineTo(pt.x, pt.y)
                if (ret) lineTo(start.x, start.y)
            }
            val s2 = s1.continueStroke(p2, 0L, sweepMs, false)
            return dispatchSync(GestureDescription.Builder().addStroke(s2).build())
        } else {
            val pf = Path().apply {
                moveTo(icon.x, icon.y); lineTo(start.x, start.y)
                for (pt in snake) lineTo(pt.x, pt.y)
                if (ret) lineTo(start.x, start.y)
            }
            return dispatchSync(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(pf, 0L, holdMs + sweepMs)).build())
        }
    }

    private fun dispatchSync(g: GestureDescription): Boolean {
        if (running) waitForGame()
        val l = CountDownLatch(1)
        var ok = false
        val sent = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { ok = true; l.countDown() }
            override fun onCancelled(gestureDescription: GestureDescription?) { l.countDown() }
        }, mainHandler)
        if (!sent) return false
        runCatching { l.await(15, TimeUnit.SECONDS) }
        return ok
    }

    private fun takeScreen(): Bitmap? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        val l = CountDownLatch(1)
        var res: Bitmap? = null
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(s: ScreenshotResult) {
                runCatching {
                    val hw = Bitmap.wrapHardwareBuffer(s.hardwareBuffer, s.colorSpace)
                    res = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    hw?.recycle()
                    s.hardwareBuffer.close()
                }
                l.countDown()
            }
            override fun onFailure(errorCode: Int) { l.countDown() }
        })
        runCatching { l.await(4, TimeUnit.SECONDS) }
        return res
    }

    private fun sleepMs(ms: Long) { try { Thread.sleep(ms.coerceAtLeast(10L)) } catch (_: InterruptedException) {} }
}
