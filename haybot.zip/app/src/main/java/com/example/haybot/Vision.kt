package com.example.haybot

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.roundToInt
import kotlin.math.sqrt

object Vision {
    const val PS = 32
    private const val HP = 16
    private const val R = 8
    private const val STEP = 2
    // сравниваем только верх иконки: внизу рисуются цифры количества, они меняются
    private const val MR0 = 2
    private const val MR1 = 22
    private const val MC0 = 4
    private const val MC1 = 28

    fun sampleColor(bmp: Bitmap, p: P): Int {
        val cx = p.x.roundToInt().coerceIn(0, bmp.width - 1)
        val cy = p.y.roundToInt().coerceIn(0, bmp.height - 1)
        var r = 0; var g = 0; var b = 0; var cnt = 0
        for (dy in -2..2) {
            val y = (cy + dy).coerceIn(0, bmp.height - 1)
            for (dx in -2..2) {
                val x = (cx + dx).coerceIn(0, bmp.width - 1)
                val c = bmp.getPixel(x, y)
                r += Color.red(c); g += Color.green(c); b += Color.blue(c); cnt++
            }
        }
        return Color.rgb(r / cnt, g / cnt, b / cnt)
    }

    fun matchesColor(bmp: Bitmap, p: P, ref: Int, maxDist: Double = 52.0): Boolean {
        val c = sampleColor(bmp, p)
        val dr = (Color.red(c) - Color.red(ref)).toDouble()
        val dg = (Color.green(c) - Color.green(ref)).toDouble()
        val db = (Color.blue(c) - Color.blue(ref)).toDouble()
        return sqrt(dr * dr + dg * dg + db * db) <= maxDist
    }

    private fun gray(c: Int): Int = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000

    /** Серый патч PS x PS вокруг точки. */
    fun extractPatch(bmp: Bitmap, center: P): IntArray {
        val cx = center.x.roundToInt()
        val cy = center.y.roundToInt()
        val out = IntArray(PS * PS)
        var i = 0
        for (dy in -HP until HP) {
            val y = (cy + dy).coerceIn(0, bmp.height - 1)
            for (dx in -HP until HP) {
                val x = (cx + dx).coerceIn(0, bmp.width - 1)
                out[i++] = gray(bmp.getPixel(x, y))
            }
        }
        return out
    }

    private fun ncc(ref: IntArray, region: IntArray, rw: Int, ox: Int, oy: Int): Double {
        var n = 0
        var sa = 0.0; var sb = 0.0; var saa = 0.0; var sbb = 0.0; var sab = 0.0
        for (r in MR0 until MR1) {
            for (c in MC0 until MC1) {
                val a = ref[r * PS + c].toDouble()
                val b = region[(oy + r) * rw + ox + c].toDouble()
                sa += a; sb += b; saa += a * a; sbb += b * b; sab += a * b; n++
            }
        }
        val va = saa - sa * sa / n
        val vb = sbb - sb * sb / n
        if (va < 1e-6 || vb < 1e-6) return 0.0
        return (sab - sa * sb / n) / sqrt(va * vb)
    }

    /** Ищет ячейку, где лежит эталонная иконка. Нормированная корреляция, устойчива к яркости. */
    fun findCrop(bmp: Bitmap, cands: List<P>, ref: IntArray?, threshold: Double = 0.72): P? {
        if (cands.isEmpty()) return null
        if (ref == null || ref.size != PS * PS) return cands.first()
        val rw = PS + 2 * R
        var best: P? = null
        var bestS = -1.0
        var second = -1.0
        for (pt in cands) {
            val cx = pt.x.roundToInt()
            val cy = pt.y.roundToInt()
            val region = IntArray(rw * rw)
            var i = 0
            for (yy in 0 until rw) {
                val y = (cy - HP - R + yy).coerceIn(0, bmp.height - 1)
                for (xx in 0 until rw) {
                    val x = (cx - HP - R + xx).coerceIn(0, bmp.width - 1)
                    region[i++] = gray(bmp.getPixel(x, y))
                }
            }
            var s = -1.0
            var oy = 0
            while (oy <= 2 * R) {
                var ox = 0
                while (ox <= 2 * R) {
                    val v = ncc(ref, region, rw, ox, oy)
                    if (v > s) s = v
                    ox += STEP
                }
                oy += STEP
            }
            if (s > bestS) { second = bestS; bestS = s; best = pt }
            else if (s > second) second = s
        }
        return if (bestS >= threshold && (second < 0.0 || bestS - second >= 0.02)) best else null
    }
}
