package com.example.haybot

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

data class P(val x: Float, val y: Float)

enum class T(val icon: String, val label: String, val multi: Boolean, val min: Int, val color: Int) {
    FIELD("🌱", "Грядка", false, 1, 0xFF4CAF50.toInt()),
    WHEAT("🌾", "Культура", false, 1, 0xFFFFC107.toInt()),
    AREA("🧭", "Поле", true, 4, 0xFF29B6F6.toInt()),
    HFIELD("🌿", "Грядка (сбор)", false, 1, 0xFF8BC34A.toInt()),
    SICKLE("🔪", "Серп", false, 1, 0xFFEF5350.toInt()),
    GROUND("🟫", "Пустая земля", false, 0, 0xFF8D6E63.toInt()),
    SHOP("🏪", "Лавка", false, 0, 0xFFAB47BC.toInt()),
    SLOT("🧺", "Слот", true, 1, 0xFFFF7043.toInt()),
    SWIPE("↔", "Листание лавки", true, 0, 0xFF7E57C2.toInt()),
    SLOT2("🧺²", "Слоты стр. 2", true, 0, 0xFFFF8A65.toInt()),
    SLOT3("🧺³", "Слоты стр. 3", true, 0, 0xFFFFAB91.toInt()),
    ITEM("📦", "Товар", false, 1, 0xFFFFCA28.toInt()),
    ITEMS("🔎", "Ячейки списка", true, 0, 0xFFFFE082.toInt()),
    EXTRA("➕", "Доп. кнопка", true, 0, 0xFF26A69A.toInt()),
    AD("📢", "Реклама", false, 0, 0xFFEC407A.toInt()),
    PUT("✅", "Выставить", false, 1, 0xFF66BB6A.toInt()),
    CLOSE("❌", "Закрыть", false, 1, 0xFFE53935.toInt())
}

class Cfg(ctx: Context) {
    private val sp: SharedPreferences = ctx.applicationContext.getSharedPreferences("cfg2", Context.MODE_PRIVATE)
    @Volatile private var pts: Map<T, MutableList<P>> = emptyMap()
    var onExternalChange: (() -> Unit)? = null

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "rev") {
            reload()
            onExternalChange?.invoke()
        }
    }

    init {
        reload()
        sp.registerOnSharedPreferenceChangeListener(listener)
    }

    private fun gi(k: String, d: Int, lo: Int, hi: Int = Int.MAX_VALUE): Int = sp.getInt(k, d).coerceIn(lo, hi)
    private fun pi(k: String, v: Int, lo: Int, hi: Int = Int.MAX_VALUE) {
        sp.edit().putInt(k, v.coerceIn(lo, hi)).apply()
    }

    fun reload() {
        val m = HashMap<T, MutableList<P>>()
        for (t in T.values()) m[t] = dec(sp.getString(t.name, null))
        pts = m
    }

    var sellEvery: Int
        get() = gi("every", 3, 1, 9)
        set(v) { pi("every", v, 1, 9) }
    var rowGap: Int
        get() = gi("gap", 45, 15, 150)
        set(v) { pi("gap", v, 15, 150) }
    var holdMs: Int
        get() = gi("hold", 600, 100, 2000)
        set(v) { pi("hold", v, 100, 2000) }
    var groundMs: Int
        get() = gi("gms", 1800, 600, 4000)
        set(v) { pi("gms", v, 600, 4000) }
    var edgePct: Int
        get() = gi("edge", 12, 0, 25)
        set(v) { pi("edge", v, 0, 25) }
    var shopPages: Int
        get() = gi("spages", 1, 1, 6)
        set(v) { pi("spages", v, 1, 6) }
    var swipeMs: Int
        get() = gi("swms", 700, 400, 2000)
        set(v) { pi("swms", v, 400, 2000) }
    var grow: Int
        get() = gi("grow", 120, 20, 3600)
        set(v) { pi("grow", v, 20, 3600) }
    var cells: Int
        get() = gi("cells", 60, 0)
        set(v) { pi("cells", v, 0) }
    var perCell: Int
        get() = gi("pcell", 2, 1)
        set(v) { pi("pcell", v, 1) }
    var perSlot: Int
        get() = gi("pslot", 10, 1)
        set(v) { pi("pslot", v, 1) }
    var barnCap: Int
        get() = gi("bcap", 300, 0)
        set(v) { pi("bcap", v, 0) }
    var barnUsed: Int
        get() = gi("bused", 100, 0)
        set(v) { pi("bused", v, 0) }
    var margin: Int
        get() = gi("margin", 8, 0, 100)
        set(v) { pi("margin", v, 0, 100) }
    var ripeRetries: Int
        get() = gi("rret", 8, 0, 40)
        set(v) { pi("rret", v, 0, 40) }
    var ripeWaitSec: Int
        get() = gi("rwait", 10, 3, 120)
        set(v) { pi("rwait", v, 3, 120) }
    var useRec: Boolean
        get() = sp.getBoolean("rec", true)
        set(v) { sp.edit().putBoolean("rec", v).apply() }
    var returnHand: Boolean
        get() = sp.getBoolean("rhand", true)
        set(v) { sp.edit().putBoolean("rhand", v).apply() }

    fun getRef(t: T): Int? {
        val k = "ref_" + t.name
        return if (sp.contains(k)) sp.getInt(k, 0) else null
    }
    fun setRef(t: T, c: Int) { sp.edit().putInt("ref_" + t.name, c).apply() }

    fun setWheatPatch(a: IntArray) { sp.edit().putString("wpat", a.joinToString(",")).apply() }
    fun getWheatPatch(): IntArray? {
        val s = sp.getString("wpat", "") ?: ""
        if (s.isBlank()) return null
        return try { s.split(",").map { it.toInt() }.toIntArray() } catch (_: Exception) { null }
    }

    fun list(t: T): List<P> = pts[t]?.toList() ?: emptyList()
    fun first(t: T): P? = pts[t]?.firstOrNull()

    fun add(t: T, p: P) {
        val l = pts[t] ?: return
        if (!t.multi) l.clear()
        l.add(p)
        saveOne(t)
    }

    fun clear(t: T) {
        pts[t]?.clear()
        saveOne(t)
        val e = sp.edit()
        e.remove("ref_" + t.name)
        if (t == T.ITEM) e.remove("wpat")
        e.apply()
    }

    fun missing(): T? {
        for (t in listOf(T.FIELD, T.WHEAT, T.AREA, T.HFIELD, T.SICKLE)) if (list(t).size < t.min) return t
        if (first(T.SHOP) != null) {
            for (t in listOf(T.SLOT, T.ITEM, T.PUT, T.CLOSE)) if (list(t).size < t.min) return t
        }
        return null
    }

    fun shopReady(): Boolean =
        first(T.SHOP) != null && listOf(T.SLOT, T.ITEM, T.PUT, T.CLOSE).all { list(it).size >= it.min }

    fun exportJson(): String {
        val o = JSONObject()
        for ((k, v) in sp.all) if (k != "rev" && v != null) o.put(k, v)
        return o.toString()
    }

    fun importJson(s: String): Boolean {
        return try {
            val o = JSONObject(s.trim())
            if (!o.has("AREA") && !o.has("every")) return false
            val rev = sp.getInt("rev", 0) + 1
            val e = sp.edit()
            e.clear()
            val it = o.keys()
            while (it.hasNext()) {
                val k = it.next()
                when (val v = o.get(k)) {
                    is Boolean -> e.putBoolean(k, v)
                    is Int -> e.putInt(k, v)
                    is String -> e.putString(k, v)
                    else -> {}
                }
            }
            e.putInt("rev", rev)
            e.apply()
            reload()
            true
        } catch (_: Exception) { false }
    }

    private fun saveOne(t: T) {
        val l = pts[t] ?: return
        sp.edit().putString(t.name, enc(l)).apply()
    }

    private fun enc(l: List<P>) = l.joinToString(";") { "${it.x},${it.y}" }
    private fun dec(s: String?): MutableList<P> {
        if (s.isNullOrBlank()) return mutableListOf()
        return s.split(";").mapNotNull {
            val a = it.split(",")
            if (a.size == 2) P(a[0].toFloat(), a[1].toFloat()) else null
        }.toMutableList()
    }
}
