package com.example.haybot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

class MarkView(ctx: Context, private val cfg: Cfg) : View(ctx) {
    var armed = false
    var showAll = false
    var onTap: ((Float, Float) -> Unit)? = null
    var swipeMode = false
    var onSwipe: ((P, P, Long) -> Unit)? = null
    var editMode = false
    var editPts: MutableList<P>? = null

    private var downT = 0L
    private var dragIdx = -1
    private var lastX = 0f
    private var lastY = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val poly = Path()
    private val loc = IntArray(2)
    private var down = false
    private var dx = 0f
    private var dy = 0f

    private fun inside(pts: List<P>, x: Float, y: Float): Boolean {
        val q = Geo.order(pts)
        var res = false
        var j = q.size - 1
        for (i in q.indices) {
            if ((q[i].y > y) != (q[j].y > y) &&
                x < (q[j].x - q[i].x) * (y - q[i].y) / (q[j].y - q[i].y) + q[i].x
            ) res = !res
            j = i
        }
        return res
    }

    private fun handleEdit(e: MotionEvent, pts: MutableList<P>): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.rawX; lastY = e.rawY; dragIdx = -1
                var best = 110f
                for (i in pts.indices) {
                    val d = hypot(pts[i].x - e.rawX, pts[i].y - e.rawY)
                    if (d < best) { best = d; dragIdx = i }
                }
                if (dragIdx == -1 && inside(pts, e.rawX, e.rawY)) dragIdx = -2
            }
            MotionEvent.ACTION_MOVE -> {
                val ddx = e.rawX - lastX
                val ddy = e.rawY - lastY
                if (dragIdx >= 0) pts[dragIdx] = P(e.rawX, e.rawY)
                else if (dragIdx == -2) for (i in pts.indices) pts[i] = P(pts[i].x + ddx, pts[i].y + ddy)
                lastX = e.rawX; lastY = e.rawY
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragIdx = -1
        }
        return true
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!armed) return false
        val ep = editPts
        if (editMode && ep != null) return handleEdit(e, ep)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { down = true; dx = e.rawX; dy = e.rawY; downT = System.currentTimeMillis() }
            MotionEvent.ACTION_UP -> {
                if (down) {
                    down = false
                    val ux = e.rawX
                    val uy = e.rawY
                    if (swipeMode && hypot(ux - dx, uy - dy) >= 80f)
                        onSwipe?.invoke(P(dx, dy), P(ux, uy), System.currentTimeMillis() - downT)
                    else onTap?.invoke(dx, dy)
                }
            }
            MotionEvent.ACTION_CANCEL -> down = false
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        if (!armed && !showAll) return
        getLocationOnScreen(loc)
        val ox = loc[0].toFloat()
        val oy = loc[1].toFloat()
        if (armed) c.drawColor(0x30FFEB3B)
        val area: List<P> = editPts ?: cfg.list(T.AREA)
        if (area.size >= 3) {
            val q = Geo.order(area)
            poly.reset()
            poly.moveTo(q[0].x - ox, q[0].y - oy)
            for (i in 1 until q.size) poly.lineTo(q[i].x - ox, q[i].y - oy)
            poly.close()
            p.style = Paint.Style.FILL; p.color = 0x3329B6F6; c.drawPath(poly, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = T.AREA.color; c.drawPath(poly, p)
        }
        if (area.size >= 4) {
            val z = Geo.snake(area, cfg.rowGap.toFloat(), cfg.first(T.FIELD), width, height, cfg.edgePct)
            p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = 0xCCFFFFFF.toInt()
            for (i in 1 until z.size) c.drawLine(z[i - 1].x - ox, z[i - 1].y - oy, z[i].x - ox, z[i].y - oy, p)
        }
        if (editMode) {
            for (q in area) {
                p.style = Paint.Style.FILL; p.color = Color.WHITE; c.drawCircle(q.x - ox, q.y - oy, 34f, p)
                p.color = T.AREA.color; c.drawCircle(q.x - ox, q.y - oy, 24f, p)
            }
        }
        p.style = Paint.Style.FILL
        for (t in T.values()) {
            for ((i, pt) in cfg.list(t).withIndex()) {
                p.color = t.color; c.drawCircle(pt.x - ox, pt.y - oy, 20f, p)
                p.color = Color.WHITE; p.textSize = 30f
                val label = t.icon + (if (t.multi) (i + 1).toString() else "")
                c.drawText(label, pt.x - ox + 24f, pt.y - oy + 10f, p)
            }
        }
    }
}
