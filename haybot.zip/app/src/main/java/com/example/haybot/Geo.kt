package com.example.haybot

import java.util.Random
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt

object Geo {
    private val rng = Random()

    fun order(pts: List<P>): List<P> {
        if (pts.size < 3) return pts
        val cx = pts.map { it.x }.average().toFloat()
        val cy = pts.map { it.y }.average().toFloat()
        val sorted = pts.sortedBy { atan2((it.y - cy).toDouble(), (it.x - cx).toDouble()) }
        val tl = sorted.indices.minByOrNull { sorted[it].x + sorted[it].y } ?: 0
        return List(sorted.size) { i -> sorted[(tl + i) % sorted.size] }
    }

    private fun bilerp(q0: P, q1: P, q2: P, q3: P, u: Float, v: Float): P {
        val tx = q0.x + (q1.x - q0.x) * u
        val ty = q0.y + (q1.y - q0.y) * u
        val bx = q3.x + (q2.x - q3.x) * u
        val by = q3.y + (q2.y - q3.y) * u
        return P(tx + (bx - tx) * v, ty + (by - ty) * v)
    }

    /** Змейка по полю. near — точка, с которой надо начинать (ближайший угол). */
    fun snake(pts: List<P>, gap: Float, near: P?, w: Int, h: Int, edge: Int): List<P> {
        if (pts.size < 4) return pts
        val q = order(pts)
        val sc = if (near == null) 0 else (q.indices.minByOrNull { hypot(q[it].x - near.x, q[it].y - near.y) } ?: 0)
        val s = build(q[sc], q[(sc + 1) % 4], q[(sc + 2) % 4], q[(sc + 3) % 4], gap, w, h, edge).toMutableList()
        if (near != null) {
            val cn = clamp(near, w, h, edge)
            if (s.isEmpty() || hypot(s.first().x - cn.x, s.first().y - cn.y) > 12f) s.add(0, cn)
        }
        return s
    }

    private fun build(q0: P, q1: P, q2: P, q3: P, gap: Float, w: Int, h: Int, edge: Int): List<P> {
        val sideA = max(hypot(q1.x - q0.x, q1.y - q0.y), hypot(q2.x - q3.x, q2.y - q3.y))
        val sideB = max(hypot(q3.x - q0.x, q3.y - q0.y), hypot(q2.x - q1.x, q2.y - q1.y))
        val g = gap.coerceAtLeast(15f)
        val rows = max(2, (sideB / g).roundToInt() + 1)
        val cols = max(3, (sideA / (g * 0.85f)).roundToInt() + 1)
        val out = ArrayList<P>(rows * cols)
        for (r in 0 until rows) {
            val v = r.toFloat() / (rows - 1).toFloat()
            for (c in 0 until cols) {
                val ru = c.toFloat() / (cols - 1).toFloat()
                val u = if (r % 2 == 0) ru else (1f - ru)
                out.add(clamp(bilerp(q0, q1, q2, q3, u, v), w, h, edge))
            }
        }
        return out
    }

    fun clamp(p: P, w: Int, h: Int, edge: Int): P {
        if (w <= 0 || h <= 0 || edge <= 0) return p
        val pct = edge.coerceIn(0, 25) / 100f
        return P(p.x.coerceIn(w * pct, w * (1f - pct)), p.y.coerceIn(h * pct, h * (1f - pct)))
    }

    fun jitterTap(p: P): P {
        val dx = (rng.nextGaussian().toFloat() * 3f).coerceIn(-6f, 6f)
        val dy = (rng.nextGaussian().toFloat() * 3f).coerceIn(-6f, 6f)
        return P(p.x + dx, p.y + dy)
    }

    fun jitterDelay(ms: Long): Long {
        val d = ((rng.nextFloat() * 2f - 1f) * 0.12f * ms).toLong()
        return (ms + d).coerceAtLeast(30L)
    }
}
