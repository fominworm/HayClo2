package com.example.haybot

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var cfg: Cfg
    private lateinit var tvState: TextView

    private class Row(val label: String, val get: () -> Int, val set: (Int) -> Unit)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Cfg(this)
        val scroll = ScrollView(this).apply { setBackgroundColor(0xFF141418.toInt()) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(36, 40, 36, 40) }
        scroll.addView(root)

        root.addView(TextView(this).apply { text = "🌾 HayBot — Hay Day"; textSize = 20f; setTextColor(Color.parseColor("#FFCA28")) })
        tvState = TextView(this).apply { textSize = 13f; setPadding(0, 12, 0, 16) }
        root.addView(tvState)

        root.addView(Button(this).apply {
            text = "1. Включить Спец. Возможности"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "2. Открыть Hay Day"
            setOnClickListener {
                val li = packageManager.getLaunchIntentForPackage(BotService.GAME_PKG)
                if (li != null) startActivity(li)
                else Toast.makeText(this@MainActivity, "Hay Day не установлен", Toast.LENGTH_SHORT).show()
            }
        })

        val rows = listOf(
            Row("Количество грядок", { cfg.cells }, { cfg.cells = it }),
            Row("Урожай с грядки (шт.)", { cfg.perCell }, { cfg.perCell = it }),
            Row("Занято в силосе", { cfg.barnUsed }, { cfg.barnUsed = it }),
            Row("Лимит силоса", { cfg.barnCap }, { cfg.barnCap = it }),
            Row("Запас до лимита (шт.)", { cfg.margin }, { cfg.margin = it }),
            Row("Штук в слот лавки", { cfg.perSlot }, { cfg.perSlot = it }),
            Row("Продавать каждые N кругов (1..9)", { cfg.sellEvery }, { cfg.sellEvery = it }),
            Row("Время роста (сек)", { cfg.grow }, { cfg.grow = it }),
            Row("Повторов сбора, если не созрело", { cfg.ripeRetries }, { cfg.ripeRetries = it }),
            Row("Пауза между повторами (сек)", { cfg.ripeWaitSec }, { cfg.ripeWaitSec = it }),
            Row("Шаг змейки (15..150)", { cfg.rowGap }, { cfg.rowGap = it }),
            Row("Отступ от краёв, % (0..25)", { cfg.edgePct }, { cfg.edgePct = it }),
            Row("Удержание иконки (мс)", { cfg.holdMs }, { cfg.holdMs = it }),
            Row("Зажатие земли после посева (мс)", { cfg.groundMs }, { cfg.groundMs = it })
        )
        val edits = ArrayList<EditText>()
        for (r in rows) {
            root.addView(TextView(this).apply { text = r.label; setTextColor(0xFFCCCCCC.toInt()); setPadding(0, 14, 0, 2) })
            val et = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER
                setTextColor(Color.WHITE)
                setText(r.get().toString())
            }
            root.addView(et)
            edits.add(et)
        }

        val cbRec = CheckBox(this).apply {
            text = "Проверять экран (спелость, окна, поиск пшеницы)"
            setTextColor(Color.WHITE); isChecked = cfg.useRec
        }
        val cbRet = CheckBox(this).apply {
            text = "Возвращать палец в старт после змейки"
            setTextColor(Color.WHITE); isChecked = cfg.returnHand
        }
        root.addView(cbRec)
        root.addView(cbRet)

        root.addView(Button(this).apply {
            text = "💾 Сохранить настройки"
            setOnClickListener {
                for ((i, r) in rows.withIndex()) edits[i].text.toString().toIntOrNull()?.let { r.set(it) }
                cfg.useRec = cbRec.isChecked
                cfg.returnHand = cbRet.isChecked
                Toast.makeText(this@MainActivity, "Сохранено!", Toast.LENGTH_SHORT).show()
            }
        })

        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        root.addView(Button(this).apply {
            text = "📋 Копировать всю калибровку"
            setOnClickListener {
                cm.setPrimaryClip(ClipData.newPlainText("haybot", cfg.exportJson()))
                Toast.makeText(this@MainActivity, "Скопировано в буфер", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "📥 Вставить калибровку из буфера"
            setOnClickListener {
                val s = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString() ?: ""
                if (cfg.importJson(s)) {
                    Toast.makeText(this@MainActivity, "Загружено", Toast.LENGTH_SHORT).show()
                    recreate()
                } else Toast.makeText(this@MainActivity, "В буфере нет калибровки", Toast.LENGTH_SHORT).show()
            }
        })
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        val on = BotService.instance != null
        tvState.text = if (on) "🟢 Служба активна (панель поверх игры включена)"
        else "🔴 Служба выключена. Если на Android 13/14 пункт недоступен: Настройки -> Приложения -> HayBot -> ⋮ -> Разрешить ограниченные настройки."
        tvState.setTextColor(if (on) Color.GREEN else Color.parseColor("#FF7043"))
    }
}
